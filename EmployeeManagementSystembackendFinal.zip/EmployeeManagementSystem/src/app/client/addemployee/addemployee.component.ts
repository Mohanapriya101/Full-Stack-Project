import { Component, OnInit } from '@angular/core';
import { take } from 'rxjs';

import { ActivatedRoute } from '@angular/router';
import { Department } from '../../modal/department';
import { Designation } from '../../modal/designation';
import { EmployeeService } from '../../employee.service';


@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrl: './addemployee.component.css',
})
export class AddemployeeComponent implements OnInit{
  pname: string = '';
  pDescription: string = '';
  pPrice: any = '';
  pCategory: string = '';
  pQuantity: any = '';
  pImage: any = '';
  isEdit: boolean = false;
  errorMessage: string = '';
  pid: any = '';
  departmentList: Array<Department> = [];
  designationList: Array<Designation> = [];
  departmentId: number = 0;
  designationId: number = 0;

  constructor(
    private service: EmployeeService,
    private activatedRoute: ActivatedRoute
  ) {
    this.getDepartmentList();
  }

  ngOnInit(): void {
    setTimeout(() => {
      this.activatedRoute.queryParams.subscribe((res: any) => {
        console.log('>>>>>>>>', res);
        if (res && res?.pid) {
          this.isEdit = true;
          this.getEmployeeById(res?.pid);
        }
      });  
    }, 1000);
    
  }

  getDepartmentList(): void {
    this.service
      .getDepartmentList()
      .pipe(take(1))
      .subscribe((res: any) => {
        if (res && Array.isArray(res)) {
          this.departmentList = res;
        }
      });
  }

  getEmployeeById(id: any): void {
    this.service
      .getEmployeeById(id)
      .pipe(take(1))
      .subscribe((res) => {
        if (res && res?.pid) {
          this.departmentId = res?.employeeDepartment?.pc_id;
          this.designationList = res?.employeeDepartment?.designations;
          this.pid = res?.pid;
          this.pname = res?.pname;
          this.pCategory = res?.pCategory;
          this.pDescription = res?.pDescription;
          this.pImage = res?.pImage;
          this.pPrice = res?.pPrice;
          this.pQuantity = res?.pQuantity;  
          this.designationId = res?.designation?.psc_id;
          console.log('>>>>>>>>>>>>>>>>%%>>', this.designationId)
        }
        this.getSubList();
      });
  }
  addUpdateEmployee(): any {
    if (this.pname === '') {
      this.errorMessage = 'Employee name should not be blank';
      document.getElementById('errordiv')?.scrollIntoView(true);
      return;
    }

    if (this.pDescription === '') {
      this.errorMessage = 'Product Description should not be blank';
      document.getElementById('errordiv')?.scrollIntoView(true);
      return;
    }

    if (this.pPrice === '') {
      this.errorMessage = 'Product Price should not be blank';
      document.getElementById('errordiv')?.scrollIntoView(true);
      return;
    }


    if (this.pQuantity === '') {
      this.errorMessage = 'Product Quantity should not be blank';
      document.getElementById('errordiv')?.scrollIntoView(true);
      return;
    }

    if (this.pImage === '') {
      this.errorMessage = 'Product Image URL should not be blank';
      document.getElementById('errordiv')?.scrollIntoView(true);
      return;
    }
    const pCategory = this.departmentList.find((item: Department) => item.pc_id === parseInt(this.departmentId.toString()));
    const sCategory = this.designationList.find((item: Designation) => item?.psc_id === parseInt(this.designationId.toString()))
    const body: any = {
      pname: this.pname,
      pDescription: this.pDescription,
      pPrice: this.pPrice,
      productCategory: pCategory,
      subCategory: sCategory,
      pQuantity: this.pQuantity,
      pImage: this.pImage,
    };
    if (!this.isEdit) {
      this.service
        .addEmployee(body)
        .pipe(take(1))
        .subscribe((res: any) => {
          console.log('>>>>>>>>>>>>>>>>', res);
          if (res && res === 'Employee added successfully') {
            alert('Employee Added successfully');
            this.service.navigateToLink('listemployee');
          }
        });
    } else {
      body.pid = this.pid;
      this.service.updateEmployee(body).subscribe((res: any) => {
        console.log('###', res);
        if (res && res?.pid) {
          alert('Employee Updated successfully');
          this.service.navigateToLink('listemployee');
        }
      });
    }
  }

  getSubList(): void {
    console.log('####', this.departmentId);
    if (this.departmentId) {
      const subList = this.departmentList.filter((item: Department) => item?.pc_id === parseInt(this.departmentId.toString(), 10));
      console.log('>>>>>', this.designationId);
      if (subList && subList.length > 0) {
        this.designationList = subList[0].designations;
      }
    }
  }
}
