import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { take } from 'rxjs';
import { AuthService } from '../../auth.service';


@Component({
  selector: 'app-clienthome',
  templateUrl: './clienthome.component.html',
  styleUrls: ['./clienthome.component.css']
})
export class ClienthomeComponent {
  searchText: string = '';
  constructor(
   
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
  
  }
}
