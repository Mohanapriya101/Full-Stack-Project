import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Department } from './modal/department';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
 
 

  navigateToLink(arg0: string) {
    this.router.navigate(['/'+ arg0]);
  }
 
  private loginUrl = 'http://localhost:8083';
  constructor(private router:Router, private httpClient:HttpClient) { }

  
  getAllEmployee(): Observable<any>{
    return this.httpClient.get(`${this.loginUrl}/employee/employeelist`);
  }

  deleteEmployeeById(pid:any):Observable<any>{
    return this.httpClient.delete(`${this.loginUrl}/employee/deleteemployee/${pid}`,{ responseType: 'text' });
  }

  addEmployee(body: any): Observable<any>{
    return this.httpClient.post(`${this.loginUrl}/employee/addemployee`, body, { responseType: 'text' });
   }

  updateEmployee(product: any):Observable<any> {
    return this.httpClient.put(`${this.loginUrl}/employee/updateemployee/${product?.pid}`, product);
  }

  getEmployeeById(id: any): Observable<any>{
    return this.httpClient.get(`${this.loginUrl}/employee/getProductById/${id}`);
  }

  getDepartmentList(): Observable<Array<Department>> {
    return this.httpClient.get<Array<Department>>(`${this.loginUrl}/employeedepartment/list`);
  }

  addDepartment(body: any): Observable<any>{
    return this.httpClient.post(`${this.loginUrl}/employeedepartment/add`, body, { responseType: 'text' });
   }
  addDesignation(body: any): Observable<any>{
    return this.httpClient.post(`${this.loginUrl}/employeeDesignation/add`, body, { responseType: 'text' });
   }
}
