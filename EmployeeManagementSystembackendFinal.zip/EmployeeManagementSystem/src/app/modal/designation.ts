export interface Designation {
    psc_id: number
    designationName: string
}