import { Designation } from "./designation"


export interface Department {
    pc_id: number
    departmentName: string
    designations: Array<Designation>
}