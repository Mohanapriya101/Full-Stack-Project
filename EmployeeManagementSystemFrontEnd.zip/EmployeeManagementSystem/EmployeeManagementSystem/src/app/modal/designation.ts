export interface Designation {
    dc_id: number
    designationName: string
}